package com.ejercicio;

public class Ejercicio {
    public static void main(String[] args) {
        int ejmplo0 = 23;
        long ejemplo1 = 215841415;
        double ejemplo2 = 25.3624;
        boolean ejemplo3 = false;
        String ejemplo4 = "cadena de texto";

        System.out.println("ejmplo0 = " + ejmplo0);
        System.out.println("ejemplo1 = " + ejemplo1);
        System.out.println("ejemplo2 = " + ejemplo2);
        System.out.println("ejemplo3 = " + ejemplo3);
        System.out.println("ejemplo4 = " + ejemplo4);
    }
}
